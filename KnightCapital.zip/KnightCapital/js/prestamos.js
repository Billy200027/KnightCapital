function calcularTotal(monto, meses){
   return monto * (1 + 0.05 * meses);
}

async function solicitarPrestamo(){

   const monto = parseFloat(document.getElementById("monto").value);
   const meses = parseInt(document.getElementById("meses").value);

   if(monto < 40 || monto > 300){
       alert("Monto permitido entre 40 y 300");
       return;
   }

   const total = calcularTotal(monto, meses);

   const usuario = JSON.parse(localStorage.getItem("usuario"));

   await supabaseClient.from("prestamos").insert([
      {
         usuario_id: usuario.id,
         monto,
         meses,
         total,
         estado: "pendiente",
         fecha: new Date()
      }
   ]);

   alert("Solicitud enviada");
}


async function cargarPrestamos(){

   const usuario = JSON.parse(localStorage.getItem("usuario"));

   const { data } = await supabaseClient
      .from("prestamos")
      .select("*")
      .eq("usuario_id", usuario.id);

   let html = `
      <h2>Préstamos</h2>
      <input type="number" id="monto" placeholder="Monto (40-300)">
      <input type="number" id="meses" placeholder="Meses">
      <button onclick="solicitarPrestamo()">Solicitar</button>
      <hr>
   `;

   data.forEach(p => {
      html += `
         <div class="card">
            <p>Monto: $${p.monto}</p>
            <p>Total: $${p.total}</p>
            <p>Meses: ${p.meses}</p>
            <p>Estado: ${p.estado}</p>
         </div>
      `;
   });

   document.getElementById("contenido").innerHTML = html;
}