const SUPABASE_URL = "https://vfcybpwakwlmrkuwenbs.supabase.co";
const SUPABASE_KEY = "sb_publishable_9jzYELsKtAfi95njIij-tA_68OZG4LV";

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);