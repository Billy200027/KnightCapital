async function cargarCelulares(){

   const { data, error } = await supabaseClient
      .from("celulares")
      .select("*");

   if(error) return;

   let html = "<h2>Marketplace</h2>";

   data.forEach(cel => {
      html += `
         <div class="card">
            <h3>${cel.nombre}</h3>
            <p>Precio: $${cel.precio}</p>
            <p>Colores: ${cel.colores}</p>
            <p>${cel.descripcion}</p>
            <input type="number" placeholder="Meses" id="meses_${cel.id}">
            <button onclick="solicitarCelular('${cel.id}', ${cel.precio})">
              Solicitar
            </button>
         </div>
      `;
   });

   document.getElementById("contenido").innerHTML = html;
}

function calcularTotalCel(precio, meses){
   return precio * (1 + 0.05 * meses);
}

async function solicitarCelular(celular_id, precio){

   const meses = parseInt(document.getElementById(`meses_${celular_id}`).value);

   if(!meses || meses <= 0){
      alert("Meses inválidos");
      return;
   }

   const total = calcularTotalCel(precio, meses);

   const usuario = JSON.parse(localStorage.getItem("usuario"));

   await supabaseClient.from("pagos_celulares").insert([
      {
         usuario_id: usuario.id,
         celular_id,
         meses,
         total,
         pagado: 0
      }
   ]);

   alert("Solicitud enviada");
}

