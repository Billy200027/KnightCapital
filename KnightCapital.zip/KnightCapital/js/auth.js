async function login(){

   const telefono = document.getElementById("telefono").value.trim();
   const password = document.getElementById("password").value.trim();

   console.log("Intentando login con:", telefono, password);

   const { data, error } = await supabaseClient
      .from("usuarios")
      .select("*")
      .eq("telefono", telefono)
      .eq("password", password);

   console.log("Respuesta Supabase:", data, error);

   if(error){
      alert("Error conexión base");
      return;
   }

   if(data.length === 0){
      alert("Datos incorrectos");
      return;
   }

   localStorage.setItem("usuario", JSON.stringify(data[0]));
   window.location.href = "dashboard.html";
}