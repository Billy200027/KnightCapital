function logout(){
   localStorage.removeItem("usuario");
   window.location.href = "login.html";
}

function mostrar(seccion){

   if(seccion === "perfil"){
      cargarPerfil();
   }

   if(seccion === "prestamos"){
      cargarPrestamos();
   }

   if(seccion === "celulares"){
      cargarCelulares();
   }
}

async function cargarPerfil(){

   const usuario = JSON.parse(localStorage.getItem("usuario"));

   let html = `
      <h2>Perfil</h2>
      <p><b>Teléfono:</b> ${usuario.telefono}</p>
      <p><b>Cédula:</b> ${usuario.cedula}</p>
      <p><b>Dirección:</b> ${usuario.direccion}</p>
      <p><b>Fecha nacimiento:</b> ${usuario.fecha_nacimiento}</p>
      <p><b>Edad:</b> ${usuario.edad}</p>
      <p><b>Cuenta bancaria:</b> ${usuario.cuenta_bancaria}</p>

      <input type="password" id="newPass" placeholder="Nueva contraseña">
      <button onclick="cambiarPassword()">Cambiar contraseña</button>
   `;

   document.getElementById("contenido").innerHTML = html;
}

async function cambiarPassword(){

   const nueva = document.getElementById("newPass").value;
   const usuario = JSON.parse(localStorage.getItem("usuario"));

   await supabaseClient
      .from("usuarios")
      .update({ password: nueva })
      .eq("id", usuario.id);

   usuario.password = nueva;
   localStorage.setItem("usuario", JSON.stringify(usuario));

   alert("Contraseña actualizada");
}



document.addEventListener("DOMContentLoaded", () => {

   const usuario = localStorage.getItem("usuario");

   if(!usuario){
      window.location.href = "login.html";
      return;
   }

   cargarPerfil(); // que cargue algo por defecto
});

